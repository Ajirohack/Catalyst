# Platform Selector Summary

| Platform | Message Container | Messages | Message Text | Sender | Timestamp | Input Field | Send Button |
|----------|-------------------|---------|--------------|--------|-----------|-------------|-------------|
| web.whatsapp.com |  |  |  |  |  |  |  |
| www.messenger.com |  |  |  |  |  |  |  |
| instagram.com |  |  |  |  |  |  |  |
| www.facebook.com |  |  |  |  |  |  |  |
| discord.com |  |  |  |  |  |  |  |
| slack.com |  |  |  |  |  |  |  |
| teams.microsoft.com |  |  |  |  |  |  |  |
| telegram.org |  |  |  |  |  |  |  |
| meet.google.com |  |  |  |  |  |  |  |
| zoom.us |  |  |  |  |  |  |  |
| chat.openai.com |  |  |  |  |  |  |  |
| mail.google.com |  |  |  |  |  |  |  |
| www.linkedin.com |  |  |  |  |  |  |  |
| twitter.com |  |  |  |  |  |  |  |
| outlook.live.com |  |  |  |  |  |  |  |
| reddit.com |  |  |  |  |  |  |  |
| meet.google.com |  |  |  |  |  |  |  |
| zoom.us |  |  |  |  |  |  |  |
| web.skype.com |  |  |  |  |  |  |  |

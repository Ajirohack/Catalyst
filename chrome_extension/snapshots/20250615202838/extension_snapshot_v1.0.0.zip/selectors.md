# Required Selectors

- messageContainer
- messages
- messageText
- sender
- timestamp
- inputField
- sendButton
